# Final Project 2025 — E-Store (React + MUI + Spring Boot)

This repository matches the required structure:
- Report (2 pages) in root
- SourceCode/
  - frontend/ (npm start)
  - backend/ (Spring Boot + Maven)
  - database/ (Structure + Data in single file)

## Quick Start
### 1) Database (MySQL)
- Open `SourceCode/database/estore_dump.sql` in MySQL Workbench and run it.

### 2) Backend
- Open `SourceCode/backend` in IntelliJ
- Update DB credentials in `src/main/resources/application.properties`
- Run `EstoreBackendApplication`

### 3) Frontend
- `cd SourceCode/frontend`
- `npm install`
- `npm start`

## Presentation Tip (2 minutes)
- Show Home → products loaded from backend
- Open Postman (or browser) on `GET /api/products`
- Show Admin CRUD (add/edit/delete)
