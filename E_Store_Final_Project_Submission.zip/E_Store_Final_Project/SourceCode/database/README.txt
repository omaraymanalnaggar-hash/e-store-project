Put your DB export (Structure + Data) in a single self-contained file.
This project includes: estore_dump.sql (MySQL-compatible)
