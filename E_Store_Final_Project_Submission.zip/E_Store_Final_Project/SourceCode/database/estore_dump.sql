-- E-Store database dump (Structure + Data) - self-contained single file
-- Compatible with MySQL 8+ (also works with MariaDB with minor differences)
-- Database: estore

CREATE DATABASE IF NOT EXISTS estore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE estore;

DROP TABLE IF EXISTS products;

CREATE TABLE products (
  id BIGINT NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  description TEXT NULL,
  price DECIMAL(10,2) NOT NULL,
  image_url VARCHAR(400) NULL,
  category VARCHAR(80) NULL,
  stock INT NOT NULL DEFAULT 0,
  featured BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT INTO products (name, description, price, image_url, category, stock, featured) VALUES
('Wireless Headphones', 'Comfortable over-ear headphones with rich bass.', 49.99, 'https://picsum.photos/seed/headphones/900/600', 'Electronics', 25, TRUE),
('Smart Watch', 'Track steps, heart rate and notifications.', 79.00, 'https://picsum.photos/seed/watch/900/600', 'Electronics', 18, TRUE),
('Coffee Grinder', 'Stainless steel grinder for fresh coffee.', 34.50, 'https://picsum.photos/seed/grinder/900/600', 'Home', 40, FALSE),
('Gaming Mouse', 'High DPI mouse with RGB lighting.', 22.99, 'https://picsum.photos/seed/mouse/900/600', 'Electronics', 55, TRUE),
('Backpack', 'Water-resistant backpack for daily use.', 19.90, 'https://picsum.photos/seed/backpack/900/600', 'Fashion', 60, FALSE),
('Notebook Set', 'Premium notebooks (set of 3).', 9.99, 'https://picsum.photos/seed/notebooks/900/600', 'Office', 120, FALSE),
('Desk Lamp', 'LED lamp with brightness control.', 15.75, 'https://picsum.photos/seed/lamp/900/600', 'Home', 70, FALSE),
('Bluetooth Speaker', 'Portable speaker with clear sound.', 27.40, 'https://picsum.photos/seed/speaker/900/600', 'Electronics', 33, TRUE),
('Water Bottle', 'Insulated bottle keeps drinks cold.', 12.00, 'https://picsum.photos/seed/bottle/900/600', 'Sports', 80, FALSE),
('Yoga Mat', 'Non-slip mat for workouts.', 18.25, 'https://picsum.photos/seed/yoga/900/600', 'Sports', 45, TRUE),
('Keyboard', 'Compact mechanical keyboard.', 39.99, 'https://picsum.photos/seed/keyboard/900/600', 'Electronics', 20, FALSE),
('Sunglasses', 'UV400 protection stylish sunglasses.', 14.50, 'https://picsum.photos/seed/sunglasses/900/600', 'Fashion', 50, FALSE);
