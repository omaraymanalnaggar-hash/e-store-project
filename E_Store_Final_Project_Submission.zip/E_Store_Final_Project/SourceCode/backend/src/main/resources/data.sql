INSERT INTO products(name, description, price, image_url, category, stock, featured, created_at)
VALUES
('Demo Product', 'Created automatically in H2 profile', 10.00, 'https://picsum.photos/seed/demo/900/600', 'Demo', 10, TRUE, CURRENT_TIMESTAMP);
