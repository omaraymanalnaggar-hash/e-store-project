# E-Store Backend (Spring Boot)

## Requirements
- Java 17
- Maven
- MySQL (recommended for grading) OR run with H2 profile for quick testing

## Run with MySQL (recommended)
1) Create DB and import dump:
   - Open `../database/estore_dump.sql` in MySQL Workbench
   - Run it (creates `estore` DB and `products` table + sample data)

2) Update `src/main/resources/application.properties` with your DB username/password.

3) Run:
   - In IntelliJ: run `EstoreBackendApplication`
   - Or terminal: `mvn spring-boot:run`

Backend base URL: `http://localhost:8080/api`

## Run with H2 (quick local run)
- `mvn spring-boot:run -Dspring-boot.run.profiles=h2`

H2 console (h2 profile): `http://localhost:8080/h2-console`
