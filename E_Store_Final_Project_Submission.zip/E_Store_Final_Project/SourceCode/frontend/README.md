# E-Store Frontend (React + Material UI)

## Run
1) `npm install`
2) `npm start`

Frontend runs on: http://localhost:3000

API base URL defaults to `http://localhost:8080/api`.
You can override using `.env`:
`REACT_APP_API_BASE_URL=http://localhost:8080/api`
