import React, { useEffect, useMemo, useState } from "react";
import { getFeatured, getProducts } from "../api";
import { Grid, Typography, TextField, Stack, Alert, Skeleton } from "@mui/material";
import ProductCard from "../components/ProductCard";

export default function HomePage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [featured, setFeatured] = useState([]);
  const [all, setAll] = useState([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        setLoading(true);
        const [f, a] = await Promise.all([getFeatured(), getProducts()]);
        if (!mounted) return;
        setFeatured(f);
        setAll(a);
      } catch (e) {
        setError(e?.response?.data?.message || e.message || "Failed to load products");
      } finally {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => { mounted = false; };
  }, []);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    if (!qq) return all;
    return all.filter(p =>
      (p.name || "").toLowerCase().includes(qq) ||
      (p.category || "").toLowerCase().includes(qq)
    );
  }, [all, q]);

  return (
    <Stack spacing={3}>
      <Stack spacing={1}>
        <Typography variant="h4" sx={{ fontWeight: 900 }}>Welcome to E-Store</Typography>
        <Typography color="text.secondary">
          Homepage loads products from backend service (Spring Boot REST API).
        </Typography>
      </Stack>

      {error ? <Alert severity="error">{error}</Alert> : null}

      <TextField
        label="Search by name or category"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        fullWidth
      />

      <Stack spacing={2}>
        <Typography variant="h5" sx={{ fontWeight: 800 }}>Featured</Typography>
        <Grid container spacing={2}>
          {loading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Grid item xs={12} sm={6} md={4} key={i}>
                <Skeleton variant="rectangular" height={320} />
              </Grid>
            ))
          ) : (
            featured.slice(0, 6).map(p => (
              <Grid item xs={12} sm={6} md={4} key={p.id}>
                <ProductCard p={p} />
              </Grid>
            ))
          )}
        </Grid>
      </Stack>

      <Stack spacing={2}>
        <Typography variant="h5" sx={{ fontWeight: 800 }}>All Products</Typography>
        <Grid container spacing={2}>
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Grid item xs={12} sm={6} md={4} key={i}>
                <Skeleton variant="rectangular" height={320} />
              </Grid>
            ))
          ) : (
            filtered.map(p => (
              <Grid item xs={12} sm={6} md={4} key={p.id}>
                <ProductCard p={p} />
              </Grid>
            ))
          )}
        </Grid>
      </Stack>
    </Stack>
  );
}
