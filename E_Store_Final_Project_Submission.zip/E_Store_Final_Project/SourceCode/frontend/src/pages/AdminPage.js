import React, { useEffect, useMemo, useState } from "react";
import { createProduct, deleteProduct, getProducts, updateProduct } from "../api";
import {
  Alert, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle,
  Grid, IconButton, Stack, TextField, Typography
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";

const emptyForm = {
  name: "",
  description: "",
  price: 0,
  imageUrl: "",
  category: "",
  stock: 0,
  featured: false
};

export default function AdminPage() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [q, setQ] = useState("");

  async function refresh() {
    setError(""); setOk("");
    try {
      setLoading(true);
      const data = await getProducts();
      setItems(data);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    if (!qq) return items;
    return items.filter(p =>
      (p.name || "").toLowerCase().includes(qq) ||
      (p.category || "").toLowerCase().includes(qq)
    );
  }, [items, q]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  }

  function openEdit(p) {
    setEditing(p);
    setForm({
      name: p.name || "",
      description: p.description || "",
      price: Number(p.price || 0),
      imageUrl: p.imageUrl || "",
      category: p.category || "",
      stock: Number(p.stock || 0),
      featured: Boolean(p.featured)
    });
    setOpen(true);
  }

  async function submit() {
    setError(""); setOk("");
    try {
      const payload = {
        ...form,
        price: Number(form.price),
        stock: Number(form.stock),
        featured: Boolean(form.featured)
      };
      if (editing?.id) {
        await updateProduct(editing.id, payload);
        setOk("Updated successfully");
      } else {
        await createProduct(payload);
        setOk("Created successfully");
      }
      setOpen(false);
      await refresh();
    } catch (e) {
      setError(e?.response?.data?.message || e.message || "Failed to save");
    }
  }

  async function remove(id) {
    if (!window.confirm("Delete this product?")) return;
    setError(""); setOk("");
    try {
      await deleteProduct(id);
      setOk("Deleted successfully");
      await refresh();
    } catch (e) {
      setError(e?.response?.data?.message || e.message || "Failed to delete");
    }
  }

  return (
    <Stack spacing={3}>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ alignItems: { sm: "center" } }}>
        <Box sx={{ flexGrow: 1 }}>
          <Typography variant="h4" sx={{ fontWeight: 900 }}>Admin</Typography>
          <Typography color="text.secondary">CRUD using React + MUI connected to Spring Boot API.</Typography>
        </Box>
        <Button variant="contained" onClick={openCreate}>Add Product</Button>
      </Stack>

      {error ? <Alert severity="error">{error}</Alert> : null}
      {ok ? <Alert severity="success">{ok}</Alert> : null}

      <TextField
        label="Search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        fullWidth
      />

      {loading ? (
        <Typography color="text.secondary">Loading...</Typography>
      ) : (
        <Grid container spacing={2}>
          {filtered.map(p => (
            <Grid key={p.id} item xs={12}>
              <Box
                sx={{
                  p: 2,
                  borderRadius: 3,
                  border: "1px solid rgba(255,255,255,0.08)",
                  display: "flex",
                  gap: 2,
                  alignItems: "center"
                }}
              >
                <Box sx={{ flexGrow: 1 }}>
                  <Typography sx={{ fontWeight: 800 }}>{p.name}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    ${Number(p.price).toFixed(2)} • Stock: {p.stock ?? 0}
                  </Typography>
                  <Stack direction="row" spacing={1} sx={{ mt: 1, flexWrap: "wrap" }}>
                    {p.category ? <Chip size="small" label={p.category} /> : null}
                    {p.featured ? <Chip size="small" color="secondary" label="Featured" /> : null}
                  </Stack>
                </Box>

                <IconButton onClick={() => openEdit(p)} aria-label="edit">
                  <EditIcon />
                </IconButton>
                <IconButton onClick={() => remove(p.id)} aria-label="delete">
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Grid>
          ))}
        </Grid>
      )}

      <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle>{editing ? "Edit Product" : "Add Product"}</DialogTitle>
        <DialogContent sx={{ pt: 1 }}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Name" value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <TextField label="Category" value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })} />
            <TextField label="Image URL" value={form.imageUrl}
              onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} />
            <TextField label="Price" type="number" value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })} />
            <TextField label="Stock" type="number" value={form.stock}
              onChange={(e) => setForm({ ...form, stock: e.target.value })} />
            <TextField label="Description" value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })} multiline rows={4} />
            <TextField
              label="Featured (true/false)"
              value={form.featured ? "true" : "false"}
              onChange={(e) => setForm({ ...form, featured: (e.target.value || "").toLowerCase() === "true" })}
              helperText="Type true or false"
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={submit}>Save</Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
