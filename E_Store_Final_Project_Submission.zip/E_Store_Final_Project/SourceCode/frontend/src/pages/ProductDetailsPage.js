import React, { useEffect, useState } from "react";
import { useParams, Link as RouterLink } from "react-router-dom";
import { getProduct } from "../api";
import { Alert, Box, Button, Chip, Stack, Typography } from "@mui/material";

export default function ProductDetailsPage() {
  const { id } = useParams();
  const [p, setP] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        setLoading(true);
        const data = await getProduct(id);
        if (mounted) setP(data);
      } catch (e) {
        setError(e?.response?.data?.message || e.message || "Failed to load product");
      } finally {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => { mounted = false; };
  }, [id]);

  if (loading) return <Typography color="text.secondary">Loading...</Typography>;
  if (error) return <Alert severity="error">{error}</Alert>;
  if (!p) return <Alert severity="warning">Product not found</Alert>;

  return (
    <Stack spacing={3}>
      <Button component={RouterLink} to="/" variant="text">← Back</Button>

      <Box
        component="img"
        src={p.imageUrl || "https://picsum.photos/seed/fallback/900/600"}
        alt={p.name}
        sx={{ width: "100%", maxHeight: 420, objectFit: "cover", borderRadius: 3, border: "1px solid rgba(255,255,255,0.08)" }}
      />

      <Stack spacing={1}>
        <Typography variant="h4" sx={{ fontWeight: 900 }}>{p.name}</Typography>
        <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
          {p.category ? <Chip label={p.category} /> : null}
          {p.featured ? <Chip color="secondary" label="Featured" /> : null}
          <Chip variant="outlined" label={`Stock: ${p.stock ?? 0}`} />
        </Stack>
        <Typography color="text.secondary" sx={{ whiteSpace: "pre-wrap" }}>
          {p.description || "No description"}
        </Typography>
        <Typography variant="h5" sx={{ mt: 2 }}>${Number(p.price).toFixed(2)}</Typography>
      </Stack>
    </Stack>
  );
}
