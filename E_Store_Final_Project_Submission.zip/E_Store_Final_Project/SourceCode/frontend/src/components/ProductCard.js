import React from "react";
import { Card, CardContent, CardMedia, Typography, Chip, Stack, Button } from "@mui/material";
import { Link as RouterLink } from "react-router-dom";

export default function ProductCard({ p }) {
  return (
    <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <CardMedia
        component="img"
        height="170"
        image={p.imageUrl || "https://picsum.photos/seed/fallback/900/600"}
        alt={p.name}
      />
      <CardContent sx={{ flexGrow: 1 }}>
        <Stack direction="row" spacing={1} sx={{ mb: 1, flexWrap: "wrap" }}>
          {p.category ? <Chip size="small" label={p.category} /> : null}
          {p.featured ? <Chip size="small" color="secondary" label="Featured" /> : null}
          <Chip size="small" variant="outlined" label={`Stock: ${p.stock ?? 0}`} />
        </Stack>
        <Typography variant="h6" sx={{ fontWeight: 800 }}>{p.name}</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {p.description || "No description"}
        </Typography>
        <Typography variant="h6" sx={{ mt: 2 }}>
          ${Number(p.price).toFixed(2)}
        </Typography>
      </CardContent>
      <CardContent sx={{ pt: 0 }}>
        <Button fullWidth variant="contained" component={RouterLink} to={`/products/${p.id}`}>
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}
