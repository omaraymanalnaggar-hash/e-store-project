import React from "react";
import { AppBar, Toolbar, Typography, Button, Container, Box } from "@mui/material";
import { Link as RouterLink } from "react-router-dom";

export default function Layout({ children }) {
  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "background.default" }}>
      <AppBar position="sticky" elevation={0} sx={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <Toolbar sx={{ display: "flex", gap: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 800, flexGrow: 1 }}>
            E-Store
          </Typography>
          <Button component={RouterLink} to="/" color="inherit">Home</Button>
          <Button component={RouterLink} to="/admin" color="inherit">Admin</Button>
        </Toolbar>
      </AppBar>

      <Container sx={{ py: 4 }}>
        {children}
      </Container>

      <Box sx={{ py: 3, borderTop: "1px solid rgba(255,255,255,0.08)", mt: 6 }}>
        <Container>
          <Typography variant="body2" color="text.secondary">
            © {new Date().getFullYear()} E-Store — React + MUI + Spring Boot
          </Typography>
        </Container>
      </Box>
    </Box>
  );
}
