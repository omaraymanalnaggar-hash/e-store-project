import { createTheme } from "@mui/material/styles";

export const theme = createTheme({
  palette: {
    mode: "dark",
    primary: { main: "#7c5cff" },
    secondary: { main: "#2ee9a4" }
  },
  shape: { borderRadius: 16 },
  typography: {
    fontFamily: ['system-ui', 'Segoe UI', 'Tahoma', 'Arial'].join(",")
  }
});
